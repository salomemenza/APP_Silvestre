package com.example.erp_mobile.model;

public class Response {
    private int Status;
    private String message;

}
