package com.example.erp_mobile.global;

import android.app.ProgressDialog;

public class variables_globales {


    public static String URL_RegistrarQR ="https://intranet.gruposilvestre.com.pe/IntranetGSIL/Almacen/frmSeguiPedido.aspx/RegistrarTrazabilidad";
    public static String URL_Login="https://intranet.gruposilvestre.com.pe/IntranetGSIL/Login2.aspx/Autenticar_Usuario";

    public static Double IGV=18.0;
    //DATOS DEL USUARIO
    public static String LOGIN_USUARIO;
    public static String LOGIN_CORREO;
    public static String LOGIN_NOMBREUSUARIO;
    public static String LOGIN_RUC;
    public static String LOGIN_PERFIL;
    public static String LOGIN_NRODNI;
    public static String LOGIN_IDEMPRESA;
    //{"d":"TRUE~398~ADM. SISTEMAS~46119959~SIS - ANDY VERA SANCHO"}
}
