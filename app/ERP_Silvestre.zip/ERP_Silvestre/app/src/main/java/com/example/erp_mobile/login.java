package com.example.erp_mobile;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.erp_mobile.global.variables_globales;
import com.example.erp_mobile.model.tblusuario;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;


public class login extends AppCompatActivity  {
    private static final String TAG = "LoginActivity";
    private static final int REQUEST_SIGNUP = 0;
    private RequestQueue queue;
    EditText txtusuario;
    EditText txtcontrasena;
    EditText txtEmpresa;
    Button btningresar;
    Button btnsalir;
    Button btninvitado;
    private static tblusuario objUsuario= new tblusuario();
    ProgressDialog progressDialog = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        handleSSLHandshake();
        txtusuario=(EditText)findViewById(R.id.txtusuario);
        txtcontrasena=(EditText)findViewById(R.id.txtcontraseña);
        btningresar=(Button)findViewById(R.id.btningresar);

        txtEmpresa=(EditText)findViewById(R.id.txtNombreEmpresa);
        //txtEmpresa.setInputType(InputType.TYPE_NULL);


        btningresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if(txtusuario.getText().toString().equals("admin") && txtcontrasena.getText().toString().equals("admin"))
//                {
//                    Intent intento= new Intent(getApplicationContext(),MainActivity.class);
//                    startActivityForResult(intento,REQUEST_SIGNUP);
//                }
                ConectarApi();
            }
        });


        txtEmpresa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerDialog = new AlertDialog.Builder(login.this,R.style.AlerDialogEstiloERP);
                alerDialog.setTitle("Seleccione Empresa");

                alerDialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        txtEmpresa.setText("SILVESTRE");
                        //LoginDialogFragment.this.getDialog().cancel();
                    }
                });
                String[] types = {"SILVESTRE", "NEOAGRUM"};

                alerDialog.setItems(types, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();


                        ListView lw = ((AlertDialog) dialog).getListView();
                        Object checkedItem = lw.getAdapter().getItem(which);
                        checkedItem.toString();
                        //Toast.makeText(getActivity(), checkedItem.toString(), Toast.LENGTH_SHORT).show();
                        txtEmpresa.setText(checkedItem.toString());

                    }

                });

                alerDialog.show();
            }
        });


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED) {


                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.CAMERA},PackageManager.PERMISSION_GRANTED);



        }

/*
        int orientation = getResources().getConfiguration().orientation;
        Log.d("CHANGESCREEN", "Orientation: " + orientation);
        switch(orientation ) {
            case Configuration.ORIENTATION_LANDSCAPE:
                // Con la orientación en horizontal actualizamos el adaptador
                //adapter.notify();
                break;
            case Configuration.ORIENTATION_PORTRAIT:
                // Con la orientación en vertical actualizamos el adaptador
                //adapter.notify();
                break;
        }
*/
    }

    public void ConectarApi()
    {
        final String usuario = txtusuario.getText().toString();
        final String password = txtcontrasena.getText().toString();

        if (usuario.isEmpty()){ //|| !android.util.Patterns.EMAIL_ADDRESS.matcher(usuario).matches()) {
            txtusuario.setError("Ingrese un usuario correcto");

        } else {
            txtusuario.setError(null);
        }

        if (password.isEmpty()){ // || password.length() < 4 || password.length() > 10) {
            txtcontrasena.setError("between 4 and 10 alphanumeric characters");

        } else {
            txtcontrasena.setError(null);
        }
        String url = variables_globales.URL_Login;
        variables_globales.LOGIN_IDEMPRESA=txtEmpresa.getText().toString().equals("SILVESTRE") ? "1" : "0";

        JSONObject postparams = new JSONObject();
        try {
            postparams.put("Empresa",variables_globales.LOGIN_IDEMPRESA);
            postparams.put("Usuario",(Object) usuario);
            postparams.put("Password", password);
        } catch (JSONException e) {
            e.printStackTrace();
        }




        progressDialog = new ProgressDialog(this);
        progressDialog.show();
        progressDialog.setContentView(R.layout.progress_bar_personalizado);
        progressDialog.show();

        JsonObjectRequest  stringRequest = new JsonObjectRequest (Request.Method.POST, url,postparams,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String respuesta=response.toString();
                        //Toast.makeText(login.this,response,Toast.LENGTH_LONG).show();
                        //{"d":"TRUE~398~ADM. SISTEMAS~46119959~SIS - ANDY VERA SANCHO"}
                        respuesta=respuesta.replace("\"","").replace("d:","").replace("{","").replace("}","");


                        String[] RespuestaArray= respuesta.split("~");
                        //objUsuario=parseData(response);

                        if(RespuestaArray[0].equals("FALSE"))
                        {
                            progressDialog.dismiss();
                            Toast.makeText(login.this, "Usuario o Password incorrecto", Toast.LENGTH_SHORT).show();
                        }
                        else {


                            variables_globales.LOGIN_PERFIL = RespuestaArray[2];
                            variables_globales.LOGIN_NRODNI = RespuestaArray[3];
                            variables_globales.LOGIN_NOMBREUSUARIO = RespuestaArray[4];


                            if (!variables_globales.LOGIN_NRODNI.equals("")) {
                                progressDialog.dismiss();
                                //variables_globales.LOGIN_CORREO=objUsuario.getEmail();
                                //variables_globales.LOGIN_NOMBREUSUARIO=objUsuario.getNomUsuario();
                                variables_globales.LOGIN_USUARIO = txtusuario.getText().toString();
                                login();

                            } else {
                                progressDialog.dismiss();
                                Toast.makeText(login.this, "Usuario o Password incorrecto", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        if(error.networkResponse==null)
                        {
                            Toast.makeText(login.this,"No hay conexión al servidor, verifique su conexión a internet.",Toast.LENGTH_LONG).show();
                        }
                        else {
                            Toast.makeText(login.this,"No hay conexión al servidor.",Toast.LENGTH_LONG).show();
                        }

                    }
                })

        {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }

        };

        queue = Volley.newRequestQueue(this );
        queue.add(stringRequest);


    }

    public void login() {
        Log.d(TAG, "Login");
        /*
        if (!validate()) {
            onLoginFailed();
            return;
        }
        */

        btningresar.setEnabled(false);
        onLoginSuccess();
/*
        final ProgressDialog progressDialog = new ProgressDialog(login.this,
                R.style.Theme_AppCompat_DayNight);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Authenticating...");
        progressDialog.show();

        //String usuario = txtusuario.getText().toString();
        //String password = txtcontrasena.getText().toString();

        // TODO: Implement your own authentication logic here.

        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        // On complete call either onLoginSuccess or onLoginFailed
                        onLoginSuccess();
                        // onLoginFailed();
                        progressDialog.dismiss();
                    }
                }, 3000);
                */
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SIGNUP) {
            if (resultCode == RESULT_OK) {

                // TODO: Implement successful signup logic here
                // By default we just finish the Activity and log them in automatically
                this.finish();
            }
        }
    }

    @Override
    public void onBackPressed() {
        // disable going back to the MainActivity
        moveTaskToBack(true);
    }

    public void onLoginSuccess() {
        btningresar.setEnabled(true);
        //public static final String LOGIN_USUARIO=txtusuario.toString().toUpperCase();
        variables_globales.LOGIN_USUARIO=txtusuario.getText().toString().toUpperCase();

        Intent intento= new Intent(login.this,MainActivity.class);
        //startActivityForResult(intento,REQUEST_SIGNUP);
        startActivity(intento);
        finish();
    }

    public void onLoginFailed() {
        Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();

        btningresar.setEnabled(true);
    }


    private void obtenerDatosVolley(){
        /*String url="direccion web";
        JsonObjectRequest request= new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArrayobj= response.getJSONArray("contacts");

                    for (int i=0; i<jsonArrayobj.length();i++)
                    {
                        JSONObject jsonobj=jsonArrayobj.getJSONObject(i);
                        String name= jsonobj.getString("name");
                        Toast.makeText(login.this, name, Toast.LENGTH_SHORT).show();//imprime algo en la pantalla

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(request);*/




        /*
        if(objUsuario != null)
            return true;
        else
            return  false;
            */
    }

    public tblusuario parseData(JSONObject response) {
        tblusuario objtblUsuario= new tblusuario();
        try {


            JSONObject jsonObject = new JSONObject();
            //jsonObject=response;
            jsonObject=response;

            //if (jsonObject.getString("status").equals("true")) {
                Log.d("VOLLEY======>",jsonObject.toString());
                JSONArray dataArray = jsonObject.getJSONArray("d");

                for (int i = 0; i < dataArray.length(); i++) {

                    JSONObject dataobj = dataArray.getJSONObject(i);
                    //Log.d("VOLLEY======>",dataobj.getString("nomUsuario"));
                    objtblUsuario.setCodUsuario(Integer.parseInt(dataobj.getString("codUsuario")));
                    objtblUsuario.setNomUsuario(dataobj.getString("nomUsuario"));
                    objtblUsuario.setLoginUsuario(dataobj.getString("loginUsuario"));
                    objtblUsuario.setContrasena(dataobj.getString("contrasena"));
                    objtblUsuario.setActivo(Integer.parseInt(dataobj.getString("activo")));
                    objtblUsuario.setEmail(dataobj.getString("email"));
                    objtblUsuario.setRuc(dataobj.getString("ruc"));
                }


                //Intent intent = new Intent(login.this,MainActivity.class);
                //startActivity(intent);
            //}
            //return objtblUsuario;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        finally {
            return objtblUsuario;
        }


    }



    @Override
    public void onConfigurationChanged(Configuration myConfig) {
        super.onConfigurationChanged(myConfig);
        int orientation = getResources().getConfiguration().orientation;
        Log.d("CHANGESCREEN", "Orientation: " + orientation);
        switch(orientation ) {
            case Configuration.ORIENTATION_LANDSCAPE:
                // Con la orientación en horizontal actualizamos el adaptador
                //adapter.notify();
                break;
            case Configuration.ORIENTATION_PORTRAIT:
                // Con la orientación en vertical actualizamos el adaptador
                //adapter.notify();
                break;
        }
    }

    /**
     * Enables https connections
     */
    @SuppressLint("TrulyRandom")
    public static void handleSSLHandshake() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }

                @Override
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }};

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String arg0, SSLSession arg1) {
                    return true;
                }
            });
        } catch (Exception ignored) {
        }
    }

}
