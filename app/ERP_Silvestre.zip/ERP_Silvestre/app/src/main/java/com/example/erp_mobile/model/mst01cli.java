package com.example.erp_mobile.model;

public class mst01cli {
    private String Codcli;
    private String RucCli;
    private String NomCli;
    private String DirCli;

    public String getCodcli() {
        return Codcli;
    }

    public void setCodcli(String codcli) {
        Codcli = codcli;
    }

    public String getRucCli() {
        return RucCli;
    }

    public void setRucCli(String rucCli) {
        RucCli = rucCli;
    }

    public String getNomCli() {
        return NomCli;
    }

    public void setNomCli(String nomCli) {
        NomCli = nomCli;
    }

    public String getDirCli() {
        return DirCli;
    }

    public void setDirCli(String dirCli) {
        DirCli = dirCli;
    }
}
