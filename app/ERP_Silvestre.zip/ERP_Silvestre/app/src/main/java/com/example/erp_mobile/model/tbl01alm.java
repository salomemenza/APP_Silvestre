package com.example.erp_mobile.model;

public class tbl01alm {
    private String CodAlm;
    private String NombreAlmacen;

    public String getCodAlm() {
        return CodAlm;
    }

    public void setCodAlm(String codAlm) {
        CodAlm = codAlm;
    }

    public String getNombreAlmacen() {
        return NombreAlmacen;
    }

    public void setNombreAlmacen(String nombreAlmacen) {
        NombreAlmacen = nombreAlmacen;
    }
}
